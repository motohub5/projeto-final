-- ══════════════════════════════════════════════════════════════
-- MotoHub — Script de criação do banco (MySQL 8+)
-- Gerado a partir do modelo EER revisado (nomes de coluna e FKs corrigidos)
--
-- Como usar no MySQL Workbench:
--   1. Abra uma nova aba de query (ícone do raio, ou Ctrl+T)
--   2. Cole este script inteiro
--   3. Execute tudo (ícone do raio amarelo, ou Ctrl+Shift+Enter)
-- ══════════════════════════════════════════════════════════════

CREATE DATABASE IF NOT EXISTS motohub
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE motohub;

-- ── RF01, RF02, RF09: cadastro, autenticação e controle de acesso ──
CREATE TABLE USUARIO (
  ID            INT AUTO_INCREMENT PRIMARY KEY,
  nome          VARCHAR(120) NOT NULL,
  email         VARCHAR(160) NOT NULL UNIQUE,
  senha_hash    VARCHAR(255) NOT NULL,
  criado_em     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ── RF03: cadastro e edição dos dados da motocicleta ──
CREATE TABLE MOTOCICLETA (
  ID                  INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id          INT NOT NULL,
  modelo              VARCHAR(100) NOT NULL,
  ano                 INT NOT NULL,
  placa               VARCHAR(10) NOT NULL,
  consumo_medio_km_l  FLOAT NOT NULL,
  CONSTRAINT fk_motocicleta_usuario
    FOREIGN KEY (usuario_id) REFERENCES USUARIO(ID)
    ON DELETE CASCADE
) ENGINE=InnoDB;

-- ── custos fixos usados no cálculo de lucro (RF05, RF06) ──
CREATE TABLE CONFIGURACAO_CUSTO (
  ID                        INT AUTO_INCREMENT PRIMARY KEY,
  motocicleta_id            INT NOT NULL UNIQUE,
  preco_combustivel         DECIMAL(8,2) NOT NULL,
  seguro_mensal             DECIMAL(8,2) NOT NULL DEFAULT 0,
  financiamento_mensal      DECIMAL(8,2) NOT NULL DEFAULT 0,
  ipva_anual                DECIMAL(8,2) NOT NULL DEFAULT 0,
  manutencao_intervalo_km   INT NOT NULL DEFAULT 3000,
  manutencao_custo          DECIMAL(8,2) NOT NULL DEFAULT 0,
  CONSTRAINT fk_configuracao_motocicleta
    FOREIGN KEY (motocicleta_id) REFERENCES MOTOCICLETA(ID)
    ON DELETE CASCADE
) ENGINE=InnoDB;

-- ── RF04: consolidação de turnos ──
CREATE TABLE TURNO (
  ID            INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id    INT NOT NULL,
  data          DATE NOT NULL,
  hora_inicio   DATETIME NOT NULL,
  hora_fim      DATETIME NULL,
  km_inicial    FLOAT NOT NULL,
  km_final      FLOAT NULL,
  CONSTRAINT fk_turno_usuario
    FOREIGN KEY (usuario_id) REFERENCES USUARIO(ID)
    ON DELETE CASCADE
) ENGINE=InnoDB;

-- ── RF04: abastecimentos registrados no turno ──
CREATE TABLE ABASTECIMENTO (
  ID          INT AUTO_INCREMENT PRIMARY KEY,
  turno_id    INT NOT NULL,
  data_hora   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  litros      FLOAT NOT NULL,
  valor       DECIMAL(8,2) NOT NULL,
  CONSTRAINT fk_abastecimento_turno
    FOREIGN KEY (turno_id) REFERENCES TURNO(ID)
    ON DELETE CASCADE
) ENGINE=InnoDB;

-- ── RF04: ganhos registrados no turno, por plataforma ──
CREATE TABLE GANHO (
  ID          INT AUTO_INCREMENT PRIMARY KEY,
  turno_id    INT NOT NULL,
  data_hora   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  plataforma  VARCHAR(50) NOT NULL,
  valor       DECIMAL(8,2) NOT NULL,
  CONSTRAINT fk_ganho_turno
    FOREIGN KEY (turno_id) REFERENCES TURNO(ID)
    ON DELETE CASCADE
) ENGINE=InnoDB;

-- ── Índices de apoio para os relatórios (RF05-RF08) ──
CREATE INDEX idx_turno_usuario_data ON TURNO(usuario_id, data);
CREATE INDEX idx_ganho_turno ON GANHO(turno_id);
CREATE INDEX idx_abastecimento_turno ON ABASTECIMENTO(turno_id);
