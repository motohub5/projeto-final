// Login e Criar conta: validação, ver/ocultar senha e redirecionamento ao painel
// Endereço do back-end (Node/Express). Se mudar a porta no .env, mude aqui também.
const API = 'http://localhost:3000/api';
const form = document.querySelector('form'),
  reg = !!form.querySelector('#confirm'),
  btn = form.querySelector('.submit');

form.noValidate = true;

const err = document.createElement('div');
err.className = 'err';
err.hidden = true;
btn.before(err);

form.querySelectorAll('#password,#confirm').forEach(inp => {
  if (inp.id == 'confirm') return;

  const w = document.createElement('div'),
    b = document.createElement('button');
  w.className = 'pw';
  b.type = 'button';
  b.textContent = 'ver';
  b.setAttribute('aria-label', 'Mostrar senha');

  inp.replaceWith(w);
  w.append(inp, b);

  b.onclick = () => {
    const s = inp.type == 'password';
    inp.type = s ? 'text' : 'password';
    const c = form.querySelector('#confirm');
    if (c) c.type = inp.type;
    b.textContent = s ? 'ocultar' : 'ver';
  };
});

const show = m => {
  err.textContent = m;
  err.hidden = false;
};

form.onsubmit = e => {
  e.preventDefault();
  err.hidden = true;

  const v = id => (form.querySelector('#' + id)?.value || '').trim(),
    pw = form.querySelector('#password').value;

  if (reg) {
    if (!v('name') || !v('email') || !pw)
      return show('Preencha nome, e-mail e senha para continuar.');
    if (pw.length < 6)
      return show('A senha deve ter ao menos 6 caracteres.');
    if (pw !== form.querySelector('#confirm').value)
      return show('As senhas não coincidem.');
    if (!form.querySelector('.terms input').checked)
      return show('É necessário aceitar os Termos e a Política de Privacidade.');
  } else if (!v('email') || !pw) return show('Preencha e-mail e senha para continuar.');

  btn.disabled = true;
  btn.textContent = reg ? 'Criando conta…' : 'Entrando…';

  // Envia para o back-end (cadastro grava no MySQL; login confere a senha)
  fetch(API + (reg ? '/cadastro' : '/login'), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(reg ? { nome: v('name'), email: v('email'), senha: pw } : { email: v('email'), senha: pw })
  })
    .then(async r => {
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(j.erro || 'Não foi possível concluir. Tente novamente.');
      localStorage.setItem('motohub_token', j.token);
      localStorage.setItem('motohub_nome', j.nome || '');
      location.href = 'painel.html';
    })
    .catch(e => {
      show(e instanceof TypeError ? 'Não consegui falar com o servidor. Confira se o back-end está rodando (node server.js).' : e.message);
      btn.disabled = false;
      btn.textContent = reg ? 'Criar Conta' : 'Entrar';
    });
};
