/* ===== DADOS — o back-end deve preencher estas variáveis em carregar() ===== */
const USER = { nome: '' };
let D = [];     // dias do mês atual: {dia:'01/10',ganho,comb,manut,seguro,outros,km,lucro,t}
let M = [];     // meses do ano:      {m:'Jan',lucro,receita,comb,manut,seguro,outros}
let PLAT = [];  // ganhos por app:    {nome:'iFood',pct:58,cor:'#ef4444'}
const moto = {
  modelo: '',
  ano: '',
  placa: '',
  consumo: '',
  preco: '',
  seguro: '',
  financ: '',
  ipva: '',
  mkm: '',
  mcusto: ''
};

/* ===== Ligação com o back-end ===== */
const API = 'http://localhost:3000/api';
const TOKEN = localStorage.getItem('motohub_token');
if (!TOKEN) location.replace('login.html'); // sem login, volta para a tela de entrar

async function api(caminho, opcoes = {}) {
  const r = await fetch(API + caminho, {
    ...opcoes,
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + TOKEN, ...(opcoes.headers || {}) }
  });
  const j = await r.json().catch(() => ({}));
  if (r.status === 401) {
    localStorage.removeItem('motohub_token');
    location.replace('login.html');
    throw new Error(j.erro || 'Sessão expirada.');
  }
  if (!r.ok) throw new Error(j.erro || 'Erro ao falar com o servidor.');
  return j;
}

async function carregar() {
  try {
    const j = await api('/painel');
    USER.nome = j.usuario.nome;
    D = j.dias;
    M = j.meses;
    PLAT = j.plataformas;
    if (j.moto) Object.assign(moto, j.moto);
  } catch (e) {
    console.error(e);
    alert('Não consegui carregar seus dados. Confira se o back-end está rodando (node server.js).');
  }
}

/* ===== Utilitários ===== */
const $ = s => document.querySelector(s);
const sum = (a, k) => a.reduce((s, x) => s + (+x[k] || 0), 0);
const fmt = v => v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }).replace(' ', '\u00a0');
const n2 = v => v.toFixed(2).replace('.', ',');

const now = new Date();
const ANO = now.getFullYear();
const MES = now.toLocaleDateString('pt-BR', { month: 'long' }).replace(/^./, c => c.toUpperCase());

const head = (k, t) => `<div class="head"><div><div class="k">${k}</div><h1>${t}</h1></div></div>`;
const IC = {"dash": "<svg class=\"ic\" viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M3.5 17a8.5 8.5 0 1 1 17 0\"/><path class=\"ac\" d=\"M12 17l4.4-5.4\"/><circle class=\"fl\" cx=\"12\" cy=\"17\" r=\"1.5\"/><path d=\"M6.3 9.3l1 .8M12 5.6v1.2M17.7 9.3l-1 .8\"/></svg>", "rel": "<svg class=\"ic\" viewBox=\"0 0 24 24\" aria-hidden=\"true\"><rect x=\"4\" y=\"12.5\" width=\"3.6\" height=\"7.5\" rx=\"1\"/><rect x=\"10.2\" y=\"8.5\" width=\"3.6\" height=\"11.5\" rx=\"1\"/><rect class=\"ac\" x=\"16.4\" y=\"4\" width=\"3.6\" height=\"16\" rx=\"1\"/></svg>", "hist": "<svg class=\"ic\" viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path class=\"ac\" d=\"M5 6.5v11\"/><circle cx=\"5\" cy=\"6\" r=\"1.6\"/><circle cx=\"5\" cy=\"12\" r=\"1.6\"/><circle cx=\"5\" cy=\"18\" r=\"1.6\"/><path d=\"M10 6h10M10 12h7M10 18h10\"/></svg>", "moto": "<svg class=\"ic\" viewBox=\"0 0 24 24\" aria-hidden=\"true\"><circle cx=\"6\" cy=\"16.5\" r=\"3.3\"/><circle cx=\"18\" cy=\"16.5\" r=\"3.3\"/><path d=\"M6 16.5l3.2-6.3h5.3l3.5 6.3\"/><path class=\"ac\" d=\"M14.5 10.2l-.9-3.2h-2.4\"/><path d=\"M9.2 10.2L8 8.4H6\"/></svg>", "down": "<svg class=\"ic\" viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path class=\"ac\" d=\"M12 4v11\"/><path class=\"ac\" d=\"M7.5 10.8l4.5 4.5 4.5-4.5\"/><path d=\"M4.5 19.5h15\"/></svg>", "capac": "<svg class=\"ic\" viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M5 17.5v-3.2a7 7 0 0 1 14 0v3.2a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1z\"/><path class=\"ac\" d=\"M11 12.6h8.4\"/><path d=\"M8.5 18.5v1.5M15.5 18.5v1.5\"/></svg>", "trend": "<svg class=\"ic\" viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M4 4v16h16\"/><path class=\"ac\" d=\"M7.5 15.5l3.8-4.2 3 2.6 5-6\"/><path class=\"ac\" d=\"M15.5 7.8h3.8v3.8\"/></svg>", "lista": "<svg class=\"ic\" viewBox=\"0 0 24 24\" aria-hidden=\"true\"><rect x=\"5\" y=\"4\" width=\"14\" height=\"17\" rx=\"2.5\"/><path d=\"M9 3h6v3H9z\"/><path class=\"ac\" d=\"M9 11h6M9 15h6M9 18h3.5\"/></svg>", "pdf": "<svg class=\"ic\" viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M7 3.5h7l4 4V20a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V4.5a1 1 0 0 1 1-1z\"/><path d=\"M14 3.5v4h4\"/><path class=\"ac\" d=\"M9 13.5h6M9 17h4\"/></svg>", "csv": "<svg class=\"ic\" viewBox=\"0 0 24 24\" aria-hidden=\"true\"><rect x=\"4\" y=\"5\" width=\"16\" height=\"14\" rx=\"2.2\"/><path d=\"M4 10h16M4 14.5h16\"/><path class=\"ac\" d=\"M10 5v14\"/></svg>", "recibo": "<svg class=\"ic\" viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M6 3.5h12V21l-3-2-3 2-3-2-3 2z\"/><path class=\"ac\" d=\"M9.5 8.5h5M9.5 12h5\"/></svg>"};
const empty = (i, t, p) => `<div class="panel empty"><i>${i}</i><b>${t}</b><p>${p}</p></div>`;
const dl = (c, p) => p > 0 ? (c >= p ? '↑ +' : '↓ ') + n2((c - p) / p * 100) + '% vs mês anterior' : '— Sem mês anterior para comparar';
const kpi = (l, v, c, s) => `<div class="kpi"><small>${l}</small><b style="color:${c || 'var(--green)'}">${v}</b>${s ? `<em style="color:${s[0] == '↓' ? '#ef4444' : s[0] == '—' ? 'var(--text-muted)' : 'var(--green)'}">${s}</em>` : ''}</div>`;
const pills = (arr, cur, cls = '') => `<div class="pills ${cls}">${arr.map(([id, l]) => `<button data-id="${id}" class="${id == cur ? 'on' : ''}">${l}</button>`).join('')}</div>`;

/* ===== Dashboard ===== */
function dashboard() {
  const g = sum(D, 'ganho');
  const l = sum(D, 'lucro');
  const km = sum(D, 'km');
  const desp = ['comb', 'manut', 'seguro', 'outros'].reduce((s, k) => s + sum(D, k), 0);
  const a = M.at(-1);
  const b = M.at(-2);
  const cmp = k => b ? dl(a[k], b[k]) : '— Sem mês anterior para comparar';
  let body = empty(IC.dash, 'Ainda não há turnos neste mês', 'Quando você registrar turnos no app, o resumo e os gráficos aparecem aqui.');

  if (D.length) {
    const mx = Math.max(...D.map(d => d.ganho), 1);
    const st = Math.ceil(mx / 4 / 50) * 50 || 50;
    const Y = v => 170 - v / (st * 4) * 166;
    const X = i => D.length > 1 ? 50 + i * 506 / (D.length - 1) : 303;
    const ev = Math.ceil(D.length / 11);
    const ln = k => D.map((d, i) => X(i).toFixed(1) + ',' + Y(d[k]).toFixed(1)).join(' ');
    const cat = [
      ['Combustível', 'comb', '#16c784'],
      ['Manutenção', 'manut', '#a78bfa'],
      ['Seguro', 'seguro', '#60a5fa'],
      ['Outros', 'outros', '#f59e0b']
    ].map(([n, k, c]) => [n, sum(D, k), c]);
    const T = cat.reduce((s, c) => s + c[1], 0);
    let off = 0;
    const arcs = cat.map(([n, v, c]) => {
      const len = v / T * 367.6;
      const r = `<circle cx="80" cy="80" r="58.5" stroke="${c}" stroke-dasharray="${Math.max(len - 3, 0)} 367.6" stroke-dashoffset="${-off}"/>`;
      off += len;
      return r;
    }).join('');

    body = `<div class="grid2"><div class="panel"><h3>Evolução do Lucro Diário</h3><div class="s">${MES} — dias trabalhados</div>
    <svg class="chart" viewBox="0 0 560 200"><g stroke="rgba(255,255,255,.04)" stroke-dasharray="3 3">${[0,1,2,3,4].map(i=>`<path d="M50 ${Y(i*st)}H556"/>`).join('')}</g>
    <g text-anchor="end">${[0,1,2,3,4].map(i=>`<text x="44" y="${Y(i*st)+4}">R$${i*st}</text>`).join('')}</g>
    <g text-anchor="middle">${D.map((d,i)=>i%ev?'':`<text x="${X(i)}" y="192">${d.dia}</text>`).join('')}</g>
    <polyline fill="none" stroke="rgba(22,199,132,.25)" stroke-width="1.5" stroke-dasharray="4 2" points="${ln('ganho')}"/>
    <polyline fill="none" stroke="#16c784" stroke-width="2" stroke-linejoin="round" points="${ln('lucro')}"/>
    <g fill="#16c784">${D.map((d,i)=>`<circle cx="${X(i)}" cy="${Y(d.lucro)}" r="3"/>`).join('')}</g></svg></div>
    <div class="panel"><h3>Despesas por categoria</h3><div class="s sm">Distribuição %</div>${T?`<svg class="donut" width="160" height="160" viewBox="0 0 160 160" fill="none" stroke-width="27"><g transform="rotate(-90 80 80)">${arcs}</g></svg>
    <div class="leg">${cat.map(([n,v,c])=>`<div><span><i style="background:${c}"></i>${n}</span><b>${Math.round(v/T*100)}%</b></div>`).join('')}</div>`:'<p class="s">Nenhuma despesa registrada.</p>'}</div></div>
    <div class="grid-eq"><div class="panel"><h3>Ganhos por plataforma</h3><div class="s" style="margin-bottom:16px">% do faturamento total</div>
    ${PLAT.length?PLAT.map(p=>`<div class="plat"><div><span>${p.nome}</span><b style="color:${p.cor}">${p.pct}%</b></div><u><i style="--w:${p.pct}%;--c:${p.cor}"></i></u></div>`).join(''):'<p class="s">Sem dados de plataformas ainda.</p>'}</div>
    <div class="panel"><h3>Últimos turnos</h3><div class="s" style="margin-bottom:16px">Resultado por dia</div>
    ${D.slice(-5).reverse().map(d=>`<div class="shift"><div><b>${d.dia}</b><small>${d.km} km · ${d.t} turnos</small></div><div><b>${fmt(d.lucro)}</b><small>R$ ${n2(d.km?d.lucro/d.km:0)}/km</small></div></div>`).join('')}</div></div>`;
  }

  $('#dashboard').innerHTML = head('VISÃO GERAL', `${MES} ${ANO}`) + `<div class="kpi-row">${kpi('Lucro Líquido', fmt(l), '', cmp('lucro'))}${kpi('Receita Bruta', fmt(g), '', cmp('receita'))}${kpi('Total Despesas', fmt(desp), 'var(--text)', '— Combustível + manutenção')}${kpi('Lucro por KM', 'R$ ' + n2(km ? l / km : 0), '', '— por km rodado')}${kpi('KM Rodados', km.toLocaleString('pt-BR') + ' km', 'var(--text)', '— ' + D.filter(d => d.lucro > 0).length + ' dias ativos')}</div>` + body;
}

/* ===== Relatórios mensais ===== */
let sm = null;
function relatorios() {
  if (!M.length) {
    $('#relatorios').innerHTML = head('ANÁLISE MENSAL', 'Relatórios Mensais') + empty(IC.trend, 'Sem relatórios ainda', 'Os relatórios mensais aparecem aqui assim que houver turnos registrados.');
    return;
  }

  if (sm === null || sm >= M.length) sm = M.length - 1;
  const r = M[sm];
  const p = M[sm - 1];
  const g = r.receita || 0;
  const d = g - r.lucro;
  const st = Math.ceil(Math.max(...M.map(x => x.lucro), 1) / 4 / 100) * 100 || 100;
  const Y = v => 190 - v / (st * 4) * 186;
  const w = 501 / M.length;
  const yy = String(ANO).slice(2);
  const rows = [
    ['Receita Bruta', g, 'var(--text)'],
    ['Combustível', r.comb, '#f59e0b'],
    ['Manutenção', r.manut, '#a78bfa'],
    ['Seguro', r.seguro, '#60a5fa'],
    ['Outros', r.outros, 'var(--text-muted)'],
    ['Lucro Líquido', r.lucro, '#16c784']
  ];

  $('#relatorios').innerHTML = head('ANÁLISE MENSAL', 'Relatórios Mensais') + pills(M.map((x, i) => [i, x.m + ' ' + yy]), sm) +
  `<div class="kpi-row">${kpi('Lucro Líquido', fmt(r.lucro), '', p ? dl(r.lucro, p.lucro) : '— Sem mês anterior para comparar')}${kpi('Receita Bruta', fmt(g), 'var(--text)')}${kpi('Total Despesas', fmt(d), '#ef4444')}</div>
  <div class="panel"><h3>Comparativo — meses do ano</h3><div class="s">Lucro líquido por mês</div>
  <svg class="chart" viewBox="0 0 560 215"><g stroke="rgba(255,255,255,.04)" stroke-dasharray="3 3">${[0,1,2,3,4].map(i=>`<path d="M55 ${Y(i*st)}H556"/>`).join('')}</g>
  <g text-anchor="end">${[0,1,2,3,4].map(i=>`<text x="50" y="${Y(i*st)+4}">R$${i*st}</text>`).join('')}</g>
  ${M.map((x,i)=>`<rect x="${58+i*w}" y="${Y(x.lucro)}" width="${w*.75}" height="${190-Y(x.lucro)}" rx="5" fill="${i==sm?'#16c784':'rgba(22,199,132,.25)'}"/><text x="${58+i*w+w*.375}" y="208" text-anchor="middle">${x.m}</text>`).join('')}</svg></div>
  <div class="panel pn"><h3>Detalhamento — ${r.m} ${yy}</h3><div class="tw"><table class="tbl"><thead><tr><th>CATEGORIA</th><th>VALOR</th><th>% DO BRUTO</th></tr></thead><tbody>
  ${rows.map((x,i)=>`<tr class="${i==5?'tot':''}"><td style="color:${x[2]};font-family:var(--font-body);font-size:13px">${x[0]}</td><td style="color:${x[2]};font-size:13px">${fmt(+x[1]||0)}</td><td>${g?Math.round((+x[1]||0)/g*100):0}%</td></tr>`).join('')}</tbody></table></div></div>`;
  $('#relatorios .pills').onclick = e => {
    if (e.target.dataset.id) {
      sm = +e.target.dataset.id;
      relatorios();
    }
  };
}

/* ===== Histórico detalhado ===== */
let hf = 'todos';
let hs = 'data';
function historico() {
  if (!D.length) {
    $('#historico').innerHTML = head('REGISTROS', 'Histórico Detalhado') + empty(IC.lista, 'Nenhum registro ainda', 'Cada dia trabalhado, com km, ganhos e despesas, será listado aqui.');
    return;
  }

  const rk = d => d.km ? d.lucro / d.km : 0;
  const L = D.filter(d => hf == 'bom' ? rk(d) >= 1.6 : hf == 'fraco' ? rk(d) < 1.6 : true)
    .sort((a, b) => hs == 'lucro' ? b.lucro - a.lucro : hs == 'km' ? b.km - a.km : 0);

  $('#historico').innerHTML = head('REGISTROS', 'Histórico Detalhado') +
  `<div class="bar-top">${pills([['todos','Todos os dias'],['bom','Dias bons (≥ R$1,60/km)'],['fraco','Dias fracos']],hf,'sm')}<label style="font-size:12px;color:var(--text-dim)">Ordenar por <select>${[['data','Data'],['lucro','Lucro'],['km','KM rodado']].map(([v,t])=>`<option value="${v}" ${v==hs?'selected':''}>${t}</option>`).join('')}</select></label></div>
  <div class="panel pn"><div class="tw"><table class="tbl"><thead><tr>${['Data','KM Rodados','Ganho Bruto','Combustível','Manutenção','Lucro Líquido','R$/km','Turnos'].map(h=>`<th>${h.toUpperCase()}</th>`).join('')}</tr></thead><tbody>
  ${L.length?L.map(d=>{const g=rk(d)>=1.6;return `<tr><td style="color:var(--text)">${d.dia}</td><td>${d.km} km</td><td style="color:var(--text)">${fmt(d.ganho)}</td><td style="color:#f59e0b">${fmt(d.comb||0)}</td><td style="color:#a78bfa">${d.manut?fmt(d.manut):'—'}</td><td style="color:var(--green);font-size:13px;font-weight:600">${fmt(d.lucro)}</td><td><span class="badge" style="color:${g?'var(--green)':'#ef4444'};background:${g?'var(--green-dim)':'rgba(239,68,68,.1)'}">R$ ${n2(rk(d))}</span></td><td style="text-align:center">${d.t}</td></tr>`}).join(''):'<tr><td colspan="8" style="text-align:center;padding:28px">Nenhum dia neste filtro.</td></tr>'}</tbody></table></div>
  <div class="foot"><span>${L.length} registro${L.length!=1?'s':''}</span><span class="mono muted">Total: <b>${fmt(sum(L,'lucro'))}</b></span></div></div>`;
  $('#historico .pills').onclick = e => {
    if (e.target.dataset.id) {
      hf = e.target.dataset.id;
      historico();
    }
  };
  $('#historico select').onchange = e => {
    hs = e.target.value;
    historico();
  };
}

/* ===== Configurar moto ===== */
function configurar() {
  const f = (l, k, pre, suf, ph) => `<div class="f"><label>${l}</label><div class="fb">${pre?`<span>${pre}</span>`:''}<input data-k="${k}" value="${moto[k]}" placeholder="${ph||'0'}">${suf?`<span>${suf}</span>`:''}</div></div>`;
  $('#configurar').innerHTML = head('CONFIGURAÇÕES', 'Configurar Moto') + `<div class="cols">
  <div class="panel"><h3>Dados da moto</h3>${f('Modelo','modelo','','','Ex.: Honda CG 160')}<div class="two">${f('Ano','ano','','','2022')}${f('Placa','placa','','','ABC-1D34')}</div>${f('Consumo médio','consumo','','km/L')}${f('Preço do combustível','preco','R$','/L')}</div>
  <div class="panel"><h3>Custos fixos mensais</h3>${f('Seguro mensal','seguro','R$')}${f('Financiamento mensal','financ','R$')}${f('IPVA anual (rateado automaticamente)','ipva','R$','/ano')}<div><div style="font-size:13px;font-weight:600;color:var(--text-muted);margin-bottom:10px">Manutenção preventiva</div><div class="two">${f('A cada quantos km','mkm','','km')}${f('Custo estimado','mcusto','R$')}</div></div></div></div>
  <div class="sum"><h3>Resumo do custo fixo mensal estimado</h3><div class="g" id="sg"></div><div class="t"><span>Total mensal</span><b id="st"></b></div></div>
  <button class="save">Salvar configurações</button>`;

  const calc = () => {
    const n = k => parseFloat(String(moto[k]).replace(',', '.')) || 0;
    const it = [
      ['Seguro', n('seguro')],
      ['Financiamento', n('financ')],
      ['IPVA rateado', n('ipva') / 12],
      ['Manutenção estimada', n('mcusto') / (n('mkm') || 1) * 1500]
    ];
    $('#sg').innerHTML = it.map(([l, v]) => `<div><small>${l}</small><b>${fmt(v)}</b></div>`).join('');
    $('#st').textContent = fmt(it.reduce((s, x) => s + x[1], 0));
  };

  calc();
  $('#configurar .save').onclick = async e => {
    const b = e.currentTarget;
    const txt0 = b.textContent;
    b.disabled = true;
    b.textContent = 'Salvando…';
    try {
      await api('/moto', {
        method: 'PUT',
        body: JSON.stringify({
          modelo: moto.modelo, ano: moto.ano, placa: moto.placa, consumo: moto.consumo,
          preco_combustivel: moto.preco, seguro_mensal: moto.seguro, financiamento_mensal: moto.financ,
          ipva_anual: moto.ipva, manutencao_intervalo_km: moto.mkm, manutencao_custo: moto.mcusto
        })
      });
      await carregar();   // recarrega do banco (os cálculos dependem dos custos salvos)
      b.textContent = 'Salvo ✓';
    } catch (err) {
      b.textContent = txt0;
      alert(err.message);
    }
    setTimeout(() => { b.disabled = false; b.textContent = txt0; }, 1600);
  };
  $('#configurar').oninput = e => {
    if (e.target.dataset.k) {
      moto[e.target.dataset.k] = e.target.value;
      calc();
      userbox();
    }
  };
}

/* ===== Exportar dados ===== */
let fm = 'pdf';
function exportar() {
  const has = D.length || M.length;
  const tot = sum(M, 'receita');
  const pct = Math.min(100, tot / 81000 * 100);
  const rest = 11 - now.getMonth();
  const mm = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
  const tips = [
    'Guarde os relatórios mensais exportados pelo MotoHub para comprovar receita no PGDAS-D.',
    'O CSV é ideal para importar no Conta Azul ou em planilhas do contador.',
    'Declare como "Transporte de Passageiros e Cargas" (CNAE 4930-2/02) se for MEI.',
    'Receita bruta anual MEI: limite de R$ 81.000,00 (2026). Acompanhe pelo painel.'
  ];

  $('#exportar').innerHTML = head('EXPORTAÇÃO', 'Exportar Dados') + `<div class="cols"><div class="panel" style="gap:20px"><h3>Configurar exportação</h3>
  <div><div class="s" style="margin-bottom:8px">Período</div><select style="width:100%;background:var(--surface-2);border:1px solid var(--border-strong);border-radius:10px;padding:10px 12px;font:13px var(--font-mono)"><option>${MES} ${ANO}</option><option>Ano ${ANO} (completo)</option></select></div>
  <div><div class="s" style="margin-bottom:10px">Formato</div><div class="fmt">${[['pdf',IC.pdf,'Relatório visual'],['csv',IC.csv,'Planilha de dados']].map(([f,i,t])=>`<button data-f="${f}" class="${f==fm?'on':''}">${i}<b>${f.toUpperCase()}</b><small>${t}</small></button>`).join('')}</div></div>
  <div><div class="s" style="margin-bottom:10px">Incluir no relatório</div>${[['Resumo financeiro',1],['Histórico diário',1],['Gráfico de evolução',1],['Despesas por categoria',1],['Dados por plataforma (iFood, Keeta...)',0]].map(([l,c])=>`<label class="chk"><input type="checkbox" ${c?'checked':''}>${l}</label>`).join('')}</div>
  <button class="dl" ${has?'':'disabled title="Sem dados para exportar"'}>${IC.down} Baixar ${fm.toUpperCase()}</button>${has?'':'<p class="s" style="margin:0;text-align:center">Disponível quando houver dados registrados.</p>'}</div>
  <div style="display:flex;flex-direction:column;gap:12px"><div class="panel"><h3 style="margin-bottom:12px;display:flex;align-items:center;gap:8px"><span class="h3ic">${IC.recibo}</span>Dicas para MEI</h3>${tips.map((t,i)=>`<div class="tip"><i>${i+1}</i><span>${t}</span></div>`).join('')}</div>
  <div class="panel"><h3>Limite MEI ${ANO}</h3><div class="s" style="margin-bottom:14px">Receita bruta acumulada no ano</div><div class="meter"><i style="width:${pct}%"></i></div><div style="display:flex;justify-content:space-between;gap:8px;font:13px var(--font-mono)"><span class="green">${fmt(tot)}</span><span style="color:var(--text-dim)">de R$ 81.000,00</span></div><div class="s" style="margin:6px 0 0">${Math.round(pct)}% do limite · ${rest} ${rest==1?'mês restante':'meses restantes'}</div></div></div></div>`;

  $('#exportar .dl').onclick = () => {
    const anoTodo = $('#exportar select').selectedIndex == 1;
    if (fm == 'pdf') return relatorioPDF(anoTodo, [...document.querySelectorAll('#exportar .chk input')].map(i => i.checked));
    const q = v => '"' + String(v).replace(/"/g, '""') + '"';
    const linhas = anoTodo
      ? [['Mês', 'Receita', 'Combustível', 'Manutenção', 'Seguro', 'Outros', 'Lucro líquido'],
         ...M.map(x => [x.m, x.receita, x.comb, x.manut, x.seguro, x.outros, x.lucro])]
      : [['Dia', 'KM', 'Ganho bruto', 'Combustível', 'Manutenção', 'Seguro', 'Outros', 'Lucro líquido', 'Turnos'],
         ...D.map(d => [d.dia, d.km, d.ganho, d.comb, d.manut, d.seguro, d.outros, d.lucro, d.t])];
    const csv = '\ufeff' + linhas.map(l => l.map(q).join(';')).join('\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    a.download = 'motohub-' + (anoTodo ? 'ano-' + ANO : MES.toLowerCase() + '-' + ANO) + '.csv';
    a.click();
    URL.revokeObjectURL(a.href);
  };
  $('#exportar .fmt').onclick = e => {
    const b = e.target.closest('button');
    if (b) {
      fm = b.dataset.f;
      exportar();
    }
  };
}

/* ===== Relatório em PDF (monta uma página própria e abre "Salvar como PDF") ===== */
function relatorioPDF(anoTodo, inc) {
  const [iResumo, iHist, iGraf, iDesp, iPlat] = inc;
  const rows = anoTodo
    ? M.map(x => ({ dia: x.m, ganho: x.receita, comb: x.comb, manut: x.manut, seguro: x.seguro, outros: x.outros, lucro: x.lucro, km: 0, t: 0 }))
    : D;
  const g = sum(rows, 'ganho'), l = sum(rows, 'lucro'), km = sum(rows, 'km');
  const desp = g - l;
  const periodo = anoTodo ? `Ano ${ANO} (Jan–${M.at(-1) ? M.at(-1).m : '—'})` : `${MES} ${ANO}`;
  const cor = v => v < 0 ? 'r-neg' : 'r-pos';
  const cat = [['Combustível', 'comb', '#16c784'], ['Manutenção', 'manut', '#a78bfa'], ['Seguro', 'seguro', '#60a5fa'], ['Outros (financ./IPVA)', 'outros', '#f59e0b']]
    .map(([n, k, c]) => [n, sum(rows, k), c]);
  const T = cat.reduce((s, c) => s + c[1], 0);

  // gráfico: linha (mês, lucro por dia) ou colunas (ano, lucro por mês)
  const vals = rows.map(r => r.lucro);
  const mx = Math.max(...vals, 1), mn = Math.min(...vals, 0), span = (mx - mn) || 1;
  const Y = v => 10 + (mx - v) / span * 150;
  const W = rows.length;
  let graf = '<p>Sem dados no período.</p>';
  if (W) {
    const eixo = [0, 1, 2, 3].map(i => { const v = mn + span * i / 3; return `<path d="M50 ${Y(v)}H600" stroke="#e5e7eb"/><text x="44" y="${Y(v) + 3}" text-anchor="end" font-size="9" fill="#666">R$${Math.round(v)}</text>`; }).join('');
    const ev = Math.ceil(W / 12);
    const rot = rows.map((r, i) => i % ev ? '' : `<text x="${anoTodo ? 50 + (i + .5) * 550 / W : (W > 1 ? 50 + i * 550 / (W - 1) : 325)}" y="182" text-anchor="middle" font-size="9" fill="#666">${r.dia}</text>`).join('');
    const corpo = anoTodo
      ? rows.map((r, i) => { const w = 550 / W, y0 = Y(0), y1 = Y(r.lucro); return `<rect x="${50 + i * w + w * .12}" y="${Math.min(y0, y1)}" width="${w * .76}" height="${Math.abs(y0 - y1)}" rx="3" fill="${r.lucro < 0 ? '#dc2626' : '#16c784'}"/>`; }).join('')
      : `<polyline fill="none" stroke="#16c784" stroke-width="2" points="${rows.map((r, i) => (W > 1 ? 50 + i * 550 / (W - 1) : 325).toFixed(1) + ',' + Y(r.lucro).toFixed(1)).join(' ')}"/>` +
        rows.map((r, i) => `<circle cx="${W > 1 ? 50 + i * 550 / (W - 1) : 325}" cy="${Y(r.lucro)}" r="2.6" fill="#16c784"/>`).join('');
    graf = `<svg viewBox="0 0 620 190" width="100%">${eixo}${corpo}${rot}</svg>`;
  }

  // rosca de despesas
  let off = 0;
  const arcos = cat.map(([n, v, c]) => { const len = T ? v / T * 367.6 : 0; const r = `<circle cx="80" cy="80" r="58.5" stroke="${c}" stroke-dasharray="${Math.max(len - 2, 0)} 367.6" stroke-dashoffset="${-off}"/>`; off += len; return r; }).join('');

  const html = `
  <div class="r-top"><div><div class="r-logo">Moto<span>Hub</span></div><h1>Relatório financeiro — ${periodo}</h1></div>
    <small><b>${USER.nome || ''}</b><br>${moto.modelo || 'Moto não configurada'}${moto.placa ? ' · ' + moto.placa : ''}<br>Gerado em ${new Date().toLocaleDateString('pt-BR')}</small></div>
  ${iResumo ? `<div class="r-sec"><h2>Resumo financeiro</h2><div class="r-kpis">
    <div><small>Receita bruta</small><b>${fmt(g)}</b></div><div><small>Total de despesas</small><b>${fmt(desp)}</b></div>
    <div><small>Lucro líquido</small><b class="${cor(l)}">${fmt(l)}</b></div>
    <div><small>${anoTodo ? 'Meses com dados' : 'Lucro por km'}</small><b>${anoTodo ? M.filter(x => x.receita > 0).length : 'R$ ' + n2(km ? l / km : 0)}</b></div></div>
    ${anoTodo ? '' : `<p style="margin-top:8px;color:#555">${km.toLocaleString('pt-BR')} km rodados · ${D.length} dias trabalhados · ${sum(D, 't')} turnos</p>`}</div>` : ''}
  ${iGraf ? `<div class="r-sec"><h2>Evolução do lucro ${anoTodo ? 'mensal' : 'diário'}</h2>${graf}</div>` : ''}
  ${iDesp ? `<div class="r-sec"><h2>Despesas por categoria</h2>${T ? `<div class="r-row"><svg width="150" height="150" viewBox="0 0 160 160" fill="none" stroke-width="27"><g transform="rotate(-90 80 80)">${arcos}</g></svg>
    <div class="r-leg" style="flex:1">${cat.map(([n, v, c]) => `<div><span><i style="background:${c}"></i>${n}</span><b>${fmt(v)} · ${Math.round(v / T * 100)}%</b></div>`).join('')}</div></div>` : '<p>Nenhuma despesa registrada.</p>'}</div>` : ''}
  ${iPlat ? `<div class="r-sec"><h2>Ganhos por plataforma <small style="font-weight:400;color:#777">(mês atual)</small></h2>${PLAT.length ? PLAT.map(p => `<div class="r-bar"><div><span>${p.nome}</span><b>${p.pct}%</b></div><u><i style="width:${p.pct}%;background:${p.cor}"></i></u></div>`).join('') : '<p>Sem ganhos por plataforma no período.</p>'}</div>` : ''}
  ${iHist ? `<div><h2>${anoTodo ? 'Histórico mensal' : 'Histórico diário'}</h2><table><thead><tr><th>${anoTodo ? 'Mês' : 'Dia'}</th>${anoTodo ? '' : '<th>KM</th>'}<th>Ganho bruto</th><th>Combustível</th><th>Manutenção</th><th>Seguro + fixos</th><th>Lucro líquido</th>${anoTodo ? '' : '<th>R$/km</th>'}</tr></thead><tbody>
    ${rows.map(r => `<tr><td>${r.dia}</td>${anoTodo ? '' : `<td>${r.km}</td>`}<td>${fmt(r.ganho)}</td><td>${fmt(r.comb || 0)}</td><td>${fmt(r.manut || 0)}</td><td>${fmt((r.seguro || 0) + (r.outros || 0))}</td><td class="${cor(r.lucro)}"><b>${fmt(r.lucro)}</b></td>${anoTodo ? '' : `<td>R$ ${n2(r.km ? r.lucro / r.km : 0)}</td>`}</tr>`).join('') || `<tr><td colspan="8" style="text-align:center">Sem registros no período.</td></tr>`}</tbody>
    <tfoot><tr><td>Total</td>${anoTodo ? '' : `<td>${km}</td>`}<td>${fmt(g)}</td><td>${fmt(sum(rows, 'comb'))}</td><td>${fmt(sum(rows, 'manut'))}</td><td>${fmt(sum(rows, 'seguro') + sum(rows, 'outros'))}</td><td class="${cor(l)}">${fmt(l)}</td>${anoTodo ? '' : `<td>R$ ${n2(km ? l / km : 0)}</td>`}</tr></tfoot></table></div>` : ''}
  <div class="r-foot">Relatório gerado pelo MotoHub · valores estimados com base nos lançamentos e custos configurados</div>`;

  const el = document.createElement('div');
  el.id = 'relatorio';
  el.innerHTML = html;
  document.body.append(el);
  const antes = document.title;
  document.title = 'MotoHub-relatorio-' + (anoTodo ? ANO : MES.toLowerCase() + '-' + ANO); // vira o nome sugerido do PDF
  window.onafterprint = () => { el.remove(); document.title = antes; window.onafterprint = null; };
  window.print();
}

/* ===== Navegação (usa o #hash da URL) ===== */
const R = { dashboard, relatorios, historico, configurar, exportar };
const userbox = () => {
  $('#u-nome').textContent = USER.nome || 'Seu nome';
  $('#u-moto').textContent = moto.modelo || 'Moto não configurada';
};

function go() {
  const v = location.hash.slice(1) in R ? location.hash.slice(1) : 'dashboard';
  document.querySelectorAll('.view').forEach(s => s.hidden = s.id != v);
  document.querySelectorAll('.nav-item').forEach(a => a.classList.toggle('on', a.dataset.view == v));
  userbox();
  R[v]();
  $('main').scrollTop = 0;
}

addEventListener('hashchange', go);
carregar().then(go);
