// Ticker do hero
const labels = [
  '54 km rodados',
  'R$ 18,00 combustível',
  '3 entregas',
  '8h de turno'
];
const tk = document.querySelector('.ticker b');
let i = 0;

setInterval(() => tk.textContent = labels[++i % labels.length], 3200);

// Animações de entrada ao rolar
const io = new IntersectionObserver(
  es => es.forEach(e => {
    if (e.isIntersecting) {
      e.target.classList.add('in');
      io.unobserve(e.target);
    }
  }),
  { threshold: .15 }
);

document.querySelectorAll('.pcards,.features,.steps,.stats .wrap,.cta .wrap,.mocks,.bars').forEach(g => {
  const kids = g.matches('.cta .wrap,.mocks') ? [g] : [...g.children];

  if (g.matches('.bars')) {
    io.observe(g);
    return;
  }

  kids.forEach((k, n) => {
    k.classList.add('rv');
    k.style.setProperty('--d', n * .1 + 's');
    io.observe(k);
  });
});
