// server.js — backend do MotoHub
// É o "garçom": recebe pedidos do site, busca/grava no MySQL e devolve a resposta.
// Rode com: node server.js

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const pool = require('./db');

const app = express();
app.use(cors());
app.use(express.json());

const JWT_SECRET = process.env.JWT_SECRET;
const LIMITE_MEI = 81000;
const PLATAFORMAS = ['iFood', 'Keeta', 'Rappi', 'Uber Eats', 'Outro'];
const CORES_PLAT = { iFood: '#ef4444', Keeta: '#ec4899', Rappi: '#fb923c', 'Uber Eats': '#16c784', Outro: '#a78bfa' };
const MESES = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];

/* ════════════════════════════════════════════════════════════
   Funções de apoio
   ════════════════════════════════════════════════════════════ */

// Evita repetir try/catch em toda rota: qualquer erro vira uma resposta 500 amigável.
const rota = (fn) => (req, res) =>
  Promise.resolve(fn(req, res)).catch((err) => {
    console.error(err);
    res.status(500).json({ erro: 'Erro interno no servidor.' });
  });

// Aceita "6,49" ou "6.49" e devolve número (ou NaN se não for número).
const num = (v) => {
  if (v === null || v === undefined || String(v).trim() === '') return NaN;
  return Number(String(v).replace(',', '.'));
};
const numOu = (v, padrao) => { const n = num(v); return Number.isNaN(n) ? padrao : n; }; // campo em branco = padrão
const r2 = (v) => Math.round((Number(v) + Number.EPSILON) * 100) / 100;
const pad = (n) => String(n).padStart(2, '0');

function hojeISO() {
  const d = new Date();
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
function mesAtual() { return hojeISO().slice(0, 7); }
function somarMeses(ym, delta) {
  const [a, m] = ym.split('-').map(Number);
  const d = new Date(Date.UTC(a, m - 1 + delta, 1));
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}`;
}
function intervaloDoMes(ym) {
  const [a, m] = ym.split('-').map(Number);
  const ultimo = new Date(Date.UTC(a, m, 0)).getUTCDate();
  return { de: `${ym}-01`, ate: `${ym}-${pad(ultimo)}` };
}
function rotuloMes(ym, curto = false) {
  const [a, m] = ym.split('-').map(Number);
  const nome = MESES[m - 1];
  return curto ? `${nome.slice(0, 3)} ${String(a).slice(2)}` : `${nome} ${a}`;
}
// Aceita data como texto ("2026-11-03") ou como objeto Date (quando o db.js é antigo, sem dateStrings)
const dataISO = (d) => (d instanceof Date
  ? `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`
  : String(d).slice(0, 10));
const ehMes = (s) => /^\d{4}-(0[1-9]|1[0-2])$/.test(s || '');
const ehData = (s) => /^\d{4}-\d{2}-\d{2}$/.test(s || '');

/* ════════════════════════════════════════════════════════════
   RF01 — Cadastro de novos usuários (motoboys)
   ════════════════════════════════════════════════════════════ */
app.post('/api/cadastro', rota(async (req, res) => {
  const nome = String(req.body.nome || '').trim();
  const email = String(req.body.email || '').trim().toLowerCase();
  const senha = String(req.body.senha || '');

  if (!nome || !email || !senha) {
    return res.status(400).json({ erro: 'Preencha nome, email e senha.' });
  }
  if (!/^\S+@\S+\.\S+$/.test(email)) {
    return res.status(400).json({ erro: 'E-mail inválido.' });
  }
  if (senha.length < 6) {
    return res.status(400).json({ erro: 'A senha precisa ter pelo menos 6 caracteres.' });
  }

  const senhaHash = await bcrypt.hash(senha, 10); // nunca guardamos a senha "crua"
  try {
    const [resultado] = await pool.query(
      'INSERT INTO usuario (nome, email, senha_hash) VALUES (?, ?, ?)',
      [nome, email, senhaHash]
    );
    const token = jwt.sign({ usuarioId: resultado.insertId }, JWT_SECRET, { expiresIn: '7d' });
    res.status(201).json({ token, nome });
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ erro: 'Este e-mail já está cadastrado.' });
    }
    throw err;
  }
}));

/* ════════════════════════════════════════════════════════════
   RF02 — Autenticação (login)
   ════════════════════════════════════════════════════════════ */
app.post('/api/login', rota(async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const senha = String(req.body.senha || '');

  const [linhas] = await pool.query(
    'SELECT ID AS id, nome, senha_hash FROM usuario WHERE email = ?',
    [email]
  );
  if (linhas.length === 0) {
    return res.status(401).json({ erro: 'E-mail ou senha incorretos.' });
  }
  const usuario = linhas[0];
  const ok = await bcrypt.compare(senha, usuario.senha_hash);
  if (!ok) {
    return res.status(401).json({ erro: 'E-mail ou senha incorretos.' });
  }
  const token = jwt.sign({ usuarioId: usuario.id }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, nome: usuario.nome });
}));

/* ════════════════════════════════════════════════════════════
   RF09 — Restringir dados financeiros ao usuário autenticado
   Roda ANTES de toda rota protegida: lê o token, descobre quem é o
   usuário e guarda o ID em req.usuarioId. Todas as consultas abaixo
   filtram por esse ID, então ninguém enxerga dado de outra pessoa.
   ════════════════════════════════════════════════════════════ */
function exigirLogin(req, res, next) {
  const cabecalho = req.headers.authorization || '';
  const token = cabecalho.split(' ')[1];
  if (!token) return res.status(401).json({ erro: 'Faça login para continuar.' });
  try {
    req.usuarioId = jwt.verify(token, JWT_SECRET).usuarioId;
    next();
  } catch {
    res.status(401).json({ erro: 'Sessão expirada, faça login novamente.' });
  }
}

app.get('/api/me', exigirLogin, rota(async (req, res) => {
  const [u] = await pool.query('SELECT nome, email FROM usuario WHERE ID = ?', [req.usuarioId]);
  if (!u.length) return res.status(401).json({ erro: 'Usuário não encontrado. Faça login novamente.' });
  const { moto } = await carregarMoto(req.usuarioId);
  res.json({ nome: u[0].nome, email: u[0].email, moto: moto ? moto.modelo : null });
}));

/* ════════════════════════════════════════════════════════════
   RF03 — Cadastro e edição dos dados da motocicleta
   (a moto e os custos fixos são salvos juntos)
   ════════════════════════════════════════════════════════════ */
async function carregarMoto(usuarioId) {
  const [motos] = await pool.query(
    `SELECT ID AS id, modelo, ano, placa, consumo_medio_km_l AS consumo
       FROM motocicleta WHERE usuario_id = ? ORDER BY ID LIMIT 1`,
    [usuarioId]
  );
  if (!motos.length) return { moto: null, config: null };
  const moto = { ...motos[0], consumo: Number(motos[0].consumo) };

  const [cfgs] = await pool.query(
    `SELECT preco_combustivel, seguro_mensal, financiamento_mensal, ipva_anual,
            manutencao_intervalo_km, manutencao_custo
       FROM configuracao_custo WHERE motocicleta_id = ? ORDER BY ID LIMIT 1`,
    [moto.id]
  );
  const c = cfgs[0] || {};
  const config = {
    preco_combustivel: Number(c.preco_combustivel || 0),
    seguro_mensal: Number(c.seguro_mensal || 0),
    financiamento_mensal: Number(c.financiamento_mensal || 0),
    ipva_anual: Number(c.ipva_anual || 0),
    manutencao_intervalo_km: Number(c.manutencao_intervalo_km || 3000),
    manutencao_custo: Number(c.manutencao_custo || 0),
  };
  return { moto, config };
}

app.get('/api/moto', exigirLogin, rota(async (req, res) => {
  res.json(await carregarMoto(req.usuarioId));
}));

const salvarMoto = rota(async (req, res) => {
  const b = req.body || {};
  const modelo = String(b.modelo || '').trim();
  const placa = String(b.placa || '').trim().toUpperCase();
  const ano = Math.trunc(num(b.ano));
  const consumo = num(b.consumo);
  const cfg = {
    preco_combustivel: numOu(b.preco_combustivel, 0),
    seguro_mensal: numOu(b.seguro_mensal, 0),
    financiamento_mensal: numOu(b.financiamento_mensal, 0),
    ipva_anual: numOu(b.ipva_anual, 0),
    manutencao_intervalo_km: Math.trunc(numOu(b.manutencao_intervalo_km, 3000)),
    manutencao_custo: numOu(b.manutencao_custo, 0),
  };

  if (!modelo) return res.status(400).json({ erro: 'Informe o modelo da moto.' });
  if (!placa) return res.status(400).json({ erro: 'Informe a placa.' });
  if (!(ano >= 1950 && ano <= new Date().getFullYear() + 1)) return res.status(400).json({ erro: 'Ano inválido.' });
  if (!(consumo > 0)) return res.status(400).json({ erro: 'Informe o consumo médio (km/L) maior que zero.' });
  for (const [k, v] of Object.entries(cfg)) {
    if (!Number.isFinite(v) || v < 0) return res.status(400).json({ erro: `Valor inválido em "${k}".` });
  }
  if (cfg.manutencao_intervalo_km <= 0) return res.status(400).json({ erro: 'O intervalo de manutenção precisa ser maior que zero.' });

  const [existente] = await pool.query(
    'SELECT ID AS id FROM motocicleta WHERE usuario_id = ? ORDER BY ID LIMIT 1',
    [req.usuarioId]
  );
  let motoId;
  if (existente.length) {
    motoId = existente[0].id;
    await pool.query(
      'UPDATE motocicleta SET modelo=?, ano=?, placa=?, consumo_medio_km_l=? WHERE ID=?',
      [modelo, ano, placa, consumo, motoId]
    );
  } else {
    const [ins] = await pool.query(
      'INSERT INTO motocicleta (usuario_id, modelo, ano, placa, consumo_medio_km_l) VALUES (?, ?, ?, ?, ?)',
      [req.usuarioId, modelo, ano, placa, consumo]
    );
    motoId = ins.insertId;
  }

  const [cfgExist] = await pool.query(
    'SELECT ID AS id FROM configuracao_custo WHERE motocicleta_id = ? ORDER BY ID LIMIT 1',
    [motoId]
  );
  const vals = [cfg.preco_combustivel, cfg.seguro_mensal, cfg.financiamento_mensal, cfg.ipva_anual, cfg.manutencao_intervalo_km, cfg.manutencao_custo];
  if (cfgExist.length) {
    await pool.query(
      `UPDATE configuracao_custo SET preco_combustivel=?, seguro_mensal=?, financiamento_mensal=?,
         ipva_anual=?, manutencao_intervalo_km=?, manutencao_custo=? WHERE ID=?`,
      [...vals, cfgExist[0].id]
    );
  } else {
    await pool.query(
      `INSERT INTO configuracao_custo (motocicleta_id, preco_combustivel, seguro_mensal, financiamento_mensal,
         ipva_anual, manutencao_intervalo_km, manutencao_custo) VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [motoId, ...vals]
    );
  }
  res.json({ ok: true });
});
app.put('/api/moto', exigirLogin, salvarMoto);
app.post('/api/motocicleta', exigirLogin, salvarMoto); // rota antiga, mantida por compatibilidade

/* ════════════════════════════════════════════════════════════
   RF04 — Turnos, abastecimentos e ganhos registrados pelo usuário
   ════════════════════════════════════════════════════════════ */
async function turnoAberto(usuarioId) {
  const [t] = await pool.query(
    `SELECT ID AS id, data, hora_inicio, km_inicial FROM turno
      WHERE usuario_id = ? AND hora_fim IS NULL ORDER BY ID DESC LIMIT 1`,
    [usuarioId]
  );
  return t[0] || null;
}

app.get('/api/turno/atual', exigirLogin, rota(async (req, res) => {
  const turno = await turnoAberto(req.usuarioId);

  // sugestão de km inicial = km final do último turno encerrado
  const [ult] = await pool.query(
    `SELECT km_final FROM turno WHERE usuario_id = ? AND km_final IS NOT NULL ORDER BY ID DESC LIMIT 1`,
    [req.usuarioId]
  );
  const ultimoKm = ult.length ? Number(ult[0].km_final) : null;

  if (!turno) return res.json({ turno: null, ultimoKm });

  const [ganhos] = await pool.query(
    'SELECT ID AS id, data_hora, plataforma, valor FROM ganho WHERE turno_id = ? ORDER BY ID DESC',
    [turno.id]
  );
  const [abast] = await pool.query(
    'SELECT ID AS id, data_hora, litros, valor FROM abastecimento WHERE turno_id = ? ORDER BY ID DESC',
    [turno.id]
  );
  res.json({
    turno: { ...turno, km_inicial: Number(turno.km_inicial) },
    ganhos: ganhos.map((g) => ({ ...g, valor: Number(g.valor) })),
    abastecimentos: abast.map((a) => ({ ...a, litros: Number(a.litros), valor: Number(a.valor) })),
    total_ganho: r2(ganhos.reduce((s, g) => s + Number(g.valor), 0)),
    total_combustivel: r2(abast.reduce((s, a) => s + Number(a.valor), 0)),
    ultimoKm,
  });
}));

app.post('/api/turno/iniciar', exigirLogin, rota(async (req, res) => {
  const km = num(req.body.km_inicial);
  if (!Number.isFinite(km) || km < 0) return res.status(400).json({ erro: 'Informe o km inicial do odômetro.' });
  if (await turnoAberto(req.usuarioId)) {
    return res.status(409).json({ erro: 'Você já tem um turno aberto. Encerre-o antes de iniciar outro.' });
  }
  const [r] = await pool.query(
    'INSERT INTO turno (usuario_id, data, hora_inicio, km_inicial) VALUES (?, CURDATE(), NOW(), ?)',
    [req.usuarioId, km]
  );
  res.status(201).json({ turnoId: r.insertId });
}));

app.post('/api/turno/encerrar', exigirLogin, rota(async (req, res) => {
  const turno = await turnoAberto(req.usuarioId);
  if (!turno) return res.status(409).json({ erro: 'Não há turno aberto.' });
  const km = num(req.body.km_final);
  if (!Number.isFinite(km)) return res.status(400).json({ erro: 'Informe o km final do odômetro.' });
  if (km < Number(turno.km_inicial)) {
    return res.status(400).json({ erro: `O km final não pode ser menor que o inicial (${Number(turno.km_inicial)}).` });
  }
  await pool.query('UPDATE turno SET hora_fim = NOW(), km_final = ? WHERE ID = ?', [km, turno.id]);
  res.json({ ok: true, km_rodado: r2(km - Number(turno.km_inicial)) });
}));

app.post('/api/abastecimento', exigirLogin, rota(async (req, res) => {
  const turno = await turnoAberto(req.usuarioId);
  if (!turno) return res.status(409).json({ erro: 'Inicie um turno antes de registrar o abastecimento.' });
  const litros = num(req.body.litros);
  const valor = num(req.body.valor);
  if (!(litros > 0)) return res.status(400).json({ erro: 'Informe os litros (maior que zero).' });
  if (!(valor > 0) || valor > 999999.99) return res.status(400).json({ erro: 'Informe um valor válido.' });
  await pool.query('INSERT INTO abastecimento (turno_id, litros, valor) VALUES (?, ?, ?)', [turno.id, litros, r2(valor)]);
  res.status(201).json({ ok: true });
}));

app.post('/api/ganho', exigirLogin, rota(async (req, res) => {
  const turno = await turnoAberto(req.usuarioId);
  if (!turno) return res.status(409).json({ erro: 'Inicie um turno antes de registrar um ganho.' });
  const plataforma = String(req.body.plataforma || '');
  const valor = num(req.body.valor);
  if (!PLATAFORMAS.includes(plataforma)) return res.status(400).json({ erro: 'Escolha a plataforma.' });
  if (!(valor > 0) || valor > 999999.99) return res.status(400).json({ erro: 'Informe um valor válido.' });
  await pool.query('INSERT INTO ganho (turno_id, plataforma, valor) VALUES (?, ?, ?)', [turno.id, plataforma, r2(valor)]);
  res.status(201).json({ ok: true });
}));

// Apagar um lançamento (só se for de um turno do próprio usuário — RF09)
async function apagarLancamento(tabela, req, res) {
  const id = Number(req.params.id);
  const [r] = await pool.query(
    `DELETE x FROM ${tabela} x JOIN turno t ON t.ID = x.turno_id WHERE x.ID = ? AND t.usuario_id = ?`,
    [id, req.usuarioId]
  );
  if (!r.affectedRows) return res.status(404).json({ erro: 'Lançamento não encontrado.' });
  res.json({ ok: true });
}
app.delete('/api/ganho/:id', exigirLogin, rota((req, res) => apagarLancamento('ganho', req, res)));
app.delete('/api/abastecimento/:id', exigirLogin, rota((req, res) => apagarLancamento('abastecimento', req, res)));

/* ════════════════════════════════════════════════════════════
   RF04 / RF05 / RF06 — Consolidação e cálculos
   Para cada dia trabalhado:
     despesas = combustível registrado + manutenção estimada (km × custo/km)
                + custos fixos rateados (seguro, financiamento, IPVA ÷ 30 por dia trabalhado)
     lucro líquido = ganhos − despesas          (RF05)
     lucro por km  = lucro líquido ÷ km rodado   (RF06)
   ════════════════════════════════════════════════════════════ */
async function buscarTurnos(usuarioId, de, ate) {
  const [rows] = await pool.query(
    `SELECT t.ID AS id, t.data, t.km_inicial, t.km_final,
            (SELECT COALESCE(SUM(g.valor), 0) FROM ganho g WHERE g.turno_id = t.ID) AS ganho,
            (SELECT COALESCE(SUM(a.valor), 0) FROM abastecimento a WHERE a.turno_id = t.ID) AS combustivel
       FROM turno t
      WHERE t.usuario_id = ? AND t.data BETWEEN ? AND ?
      ORDER BY t.data, t.ID`,
    [usuarioId, de, ate]
  );
  return rows.map((t) => ({
    id: t.id,
    data: dataISO(t.data),
    km: t.km_final === null ? 0 : Math.max(0, Number(t.km_final) - Number(t.km_inicial)),
    ganho: Number(t.ganho),
    combustivel: Number(t.combustivel),
  }));
}

function agregar(turnos, config) {
  const cfg = config || {};
  const custoKm = cfg.manutencao_intervalo_km > 0 ? (cfg.manutencao_custo || 0) / cfg.manutencao_intervalo_km : 0;
  const seguroDia = (cfg.seguro_mensal || 0) / 30;
  const outrosDia = ((cfg.financiamento_mensal || 0) + (cfg.ipva_anual || 0) / 12) / 30;

  const porDia = new Map();
  for (const t of turnos) {
    const d = porDia.get(t.data) || { data: t.data, turnos: 0, km: 0, ganho: 0, combustivel: 0 };
    d.turnos += 1; d.km += t.km; d.ganho += t.ganho; d.combustivel += t.combustivel;
    porDia.set(t.data, d);
  }

  const dias = [...porDia.values()].sort((a, b) => a.data.localeCompare(b.data)).map((d) => {
    const manutencao = d.km * custoKm;
    const despesas = d.combustivel + manutencao + seguroDia + outrosDia;
    const lucro = d.ganho - despesas;
    return {
      data: d.data, turnos: d.turnos, km: r2(d.km), ganho: r2(d.ganho),
      combustivel: r2(d.combustivel), manutencao: r2(manutencao),
      seguro: r2(seguroDia), outros_fixos: r2(outrosDia),
      despesas: r2(despesas), lucro: r2(lucro),
      lucro_km: d.km > 0 ? r2(lucro / d.km) : 0,
    };
  });

  const soma = (k) => dias.reduce((s, d) => s + d[k], 0);
  const totais = {
    ganho: r2(soma('ganho')), combustivel: r2(soma('combustivel')), manutencao: r2(soma('manutencao')),
    seguro: r2(soma('seguro')), outros_fixos: r2(soma('outros_fixos')), despesas: r2(soma('despesas')),
    lucro: r2(soma('lucro')), km: r2(soma('km')), turnos: soma('turnos'), dias_ativos: dias.length,
  };
  totais.lucro_km = totais.km > 0 ? r2(totais.lucro / totais.km) : 0;
  return { dias, totais };
}

const variacao = (atual, anterior) =>
  anterior ? r2(((atual - anterior) / Math.abs(anterior)) * 100) : null;

/* ════════════════════════════════════════════════════════════
   RF07 / RF08 — Dashboard (cards de resumo + gráfico de lucro diário)
   ════════════════════════════════════════════════════════════ */
app.get('/api/dashboard', exigirLogin, rota(async (req, res) => {
  const mes = ehMes(req.query.mes) ? req.query.mes : mesAtual();
  const { moto, config } = await carregarMoto(req.usuarioId);

  const { de, ate } = intervaloDoMes(mes);
  const ant = intervaloDoMes(somarMeses(mes, -1));
  const atual = agregar(await buscarTurnos(req.usuarioId, de, ate), config);
  const anterior = agregar(await buscarTurnos(req.usuarioId, ant.de, ant.ate), config);

  const [plat] = await pool.query(
    `SELECT g.plataforma AS name, SUM(g.valor) AS valor
       FROM ganho g JOIN turno t ON t.ID = g.turno_id
      WHERE t.usuario_id = ? AND t.data BETWEEN ? AND ?
      GROUP BY g.plataforma ORDER BY valor DESC`,
    [req.usuarioId, de, ate]
  );
  const totalPlat = plat.reduce((s, p) => s + Number(p.valor), 0);

  const t = atual.totais;
  const categorias = [
    { name: 'Combustível', valor: t.combustivel },
    { name: 'Manutenção', valor: t.manutencao },
    { name: 'Seguro', valor: t.seguro },
    { name: 'Outros', valor: t.outros_fixos },
  ].filter((c) => c.valor > 0);

  res.json({
    mes, mesLabel: rotuloMes(mes),
    configurado: !!moto,
    kpis: t,
    variacao: {
      lucro: variacao(t.lucro, anterior.totais.lucro),
      ganho: variacao(t.ganho, anterior.totais.ganho),
      lucro_km: r2(t.lucro_km - anterior.totais.lucro_km),
      tem_anterior: anterior.totais.dias_ativos > 0,
    },
    diario: atual.dias.map((d) => ({ dia: `${d.data.slice(8, 10)}/${d.data.slice(5, 7)}`, lucro: d.lucro, ganho: d.ganho })),
    despesas: categorias.map((c) => ({ ...c, value: t.despesas > 0 ? r2((c.valor / t.despesas) * 100) : 0 })),
    plataformas: plat.map((p) => ({ name: p.name, valor: r2(p.valor), value: totalPlat > 0 ? r2((Number(p.valor) / totalPlat) * 100) : 0 })),
    ultimos: atual.dias.slice(-5).reverse(),
  });
}));

/* ════════════════════════════════════════════════════════════
   Relatórios mensais — últimos 6 meses
   ════════════════════════════════════════════════════════════ */
app.get('/api/relatorios', exigirLogin, rota(async (req, res) => {
  const fim = mesAtual();
  const inicio = somarMeses(fim, -5);
  const { config } = await carregarMoto(req.usuarioId);
  const turnos = await buscarTurnos(req.usuarioId, intervaloDoMes(inicio).de, intervaloDoMes(fim).ate);

  const meses = [];
  for (let i = 0; i < 6; i++) {
    const ym = somarMeses(inicio, i);
    const t = agregar(turnos.filter((x) => x.data.startsWith(ym)), config).totais;
    meses.push({
      mes: ym, label: rotuloMes(ym, true), curto: MESES[Number(ym.slice(5)) - 1].slice(0, 3),
      ganho: t.ganho, despesas: t.despesas, lucro: t.lucro, km: t.km,
      combustivel: t.combustivel, manutencao: t.manutencao, seguro: t.seguro, outros_fixos: t.outros_fixos,
    });
  }
  res.json({ meses });
}));

/* ════════════════════════════════════════════════════════════
   Histórico detalhado (e base para a exportação)
   ════════════════════════════════════════════════════════════ */
app.get('/api/historico', exigirLogin, rota(async (req, res) => {
  const mes = mesAtual();
  const de = ehData(req.query.de) ? req.query.de : intervaloDoMes(mes).de;
  const ate = ehData(req.query.ate) ? req.query.ate : intervaloDoMes(mes).ate;
  const { config } = await carregarMoto(req.usuarioId);
  const turnos = await buscarTurnos(req.usuarioId, de, ate);
  const { dias, totais } = agregar(turnos, config);

  const [plat] = await pool.query(
    `SELECT g.plataforma AS name, SUM(g.valor) AS valor
       FROM ganho g JOIN turno t ON t.ID = g.turno_id
      WHERE t.usuario_id = ? AND t.data BETWEEN ? AND ?
      GROUP BY g.plataforma ORDER BY valor DESC`,
    [req.usuarioId, de, ate]
  );
  res.json({ de, ate, dias, totais, plataformas: plat.map((p) => ({ name: p.name, valor: r2(p.valor) })) });
}));

/* ════════════════════════════════════════════════════════════
   Limite MEI (receita bruta acumulada no ano)
   ════════════════════════════════════════════════════════════ */
app.get('/api/mei', exigirLogin, rota(async (req, res) => {
  const ano = Number(hojeISO().slice(0, 4));
  const [r] = await pool.query(
    `SELECT COALESCE(SUM(g.valor), 0) AS receita
       FROM ganho g JOIN turno t ON t.ID = g.turno_id
      WHERE t.usuario_id = ? AND t.data BETWEEN ? AND ?`,
    [req.usuarioId, `${ano}-01-01`, `${ano}-12-31`]
  );
  const receita = r2(r[0].receita);
  res.json({
    ano, receita, limite: LIMITE_MEI,
    percentual: r2((receita / LIMITE_MEI) * 100),
    meses_restantes: 12 - Number(hojeISO().slice(5, 7)),
  });
}));

/* ════════════════════════════════════════════════════════════
   PAINEL WEB — entrega tudo que o painel.html precisa numa chamada só.
   Formato idêntico ao que o painel.js espera (dias, meses, plataformas, moto).
   ════════════════════════════════════════════════════════════ */
const MESES_CURTOS = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
const txt = (v) => (v === null || v === undefined ? '' : String(v).replace('.', ','));

app.get('/api/painel', exigirLogin, rota(async (req, res) => {
  const [u] = await pool.query('SELECT nome FROM usuario WHERE ID = ?', [req.usuarioId]);
  if (!u.length) return res.status(401).json({ erro: 'Usuário não encontrado. Faça login novamente.' });
  const { moto, config } = await carregarMoto(req.usuarioId);

  const ano = Number(hojeISO().slice(0, 4));
  const mesAt = mesAtual();
  const turnos = await buscarTurnos(req.usuarioId, `${ano}-01-01`, `${ano}-12-31`);

  // dias do mês atual
  const doMes = agregar(turnos.filter((t) => t.data.startsWith(mesAt)), config).dias;
  const dias = doMes.map((d) => ({
    dia: `${d.data.slice(8, 10)}/${d.data.slice(5, 7)}`,
    ganho: d.ganho, comb: d.combustivel, manut: d.manutencao, seguro: d.seguro, outros: d.outros_fixos,
    km: d.km, lucro: d.lucro, t: d.turnos,
  }));

  // meses do ano, de janeiro até o mês atual
  const meses = [];
  for (let m = 1; m <= Number(mesAt.slice(5)); m++) {
    const ym = `${ano}-${pad(m)}`;
    const t = agregar(turnos.filter((x) => x.data.startsWith(ym)), config).totais;
    meses.push({ m: MESES_CURTOS[m - 1], lucro: t.lucro, receita: t.ganho, comb: t.combustivel, manut: t.manutencao, seguro: t.seguro, outros: t.outros_fixos });
  }

  // ganhos por plataforma (mês atual)
  const { de, ate } = intervaloDoMes(mesAt);
  const [plat] = await pool.query(
    `SELECT g.plataforma AS nome, SUM(g.valor) AS valor
       FROM ganho g JOIN turno t ON t.ID = g.turno_id
      WHERE t.usuario_id = ? AND t.data BETWEEN ? AND ?
      GROUP BY g.plataforma ORDER BY valor DESC`,
    [req.usuarioId, de, ate]
  );
  const totalPlat = plat.reduce((s, p) => s + Number(p.valor), 0);
  const plataformas = plat.map((p) => ({
    nome: p.nome, pct: totalPlat > 0 ? Math.round((Number(p.valor) / totalPlat) * 100) : 0, cor: CORES_PLAT[p.nome] || '#a78bfa',
  }));

  res.json({
    usuario: { nome: u[0].nome },
    moto: moto ? {
      modelo: moto.modelo, ano: txt(moto.ano), placa: moto.placa, consumo: txt(moto.consumo),
      preco: txt(config.preco_combustivel), seguro: txt(config.seguro_mensal), financ: txt(config.financiamento_mensal),
      ipva: txt(config.ipva_anual), mkm: txt(config.manutencao_intervalo_km), mcusto: txt(config.manutencao_custo),
    } : null,
    dias, meses, plataformas,
  });
}));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Backend rodando em http://localhost:${PORT}`));
