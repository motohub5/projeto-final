// db.js
// Aqui a gente abre uma "linha telefônica" reaproveitável com o MySQL.
// Um "pool" é tipo várias linhas telefônicas prontas, em vez de discar
// um número novo toda vez que alguém precisa falar com o banco.

require('dotenv').config();
const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  dateStrings: true, // datas chegam como texto "2026-10-23" (evita bagunça de fuso horário)
});

module.exports = pool;
