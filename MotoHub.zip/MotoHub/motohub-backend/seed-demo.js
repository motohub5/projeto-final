// seed-demo.js — OPCIONAL. Cria dados de exemplo para você testar o painel.
// Uso:  node seed-demo.js seu@email.com
// Ele grava uma moto + turnos dos últimos dias (com ganhos e abastecimentos) na conta informada.
// Para limpar depois, é só apagar os turnos dessa conta no Workbench.

async function popular(pool, email) {
  const [u] = await pool.query('SELECT ID AS id FROM usuario WHERE email = ?', [String(email).toLowerCase()]);
  if (!u.length) throw new Error('Não achei esse e-mail. Crie a conta no site primeiro.');
  const uid = u[0].id;

  const [m] = await pool.query('SELECT ID AS id FROM motocicleta WHERE usuario_id = ? LIMIT 1', [uid]);
  if (!m.length) {
    const [r] = await pool.query(
      'INSERT INTO motocicleta (usuario_id, modelo, ano, placa, consumo_medio_km_l) VALUES (?, ?, ?, ?, ?)',
      [uid, 'Honda CG 160', 2022, 'ABC1D34', 38]);
    await pool.query(
      `INSERT INTO configuracao_custo (motocicleta_id, preco_combustivel, seguro_mensal, financiamento_mensal,
         ipva_anual, manutencao_intervalo_km, manutencao_custo) VALUES (?, 6.49, 90, 350, 240, 3000, 280)`, [r.insertId]);
  }

  const plataformas = ['iFood', 'iFood', 'Keeta', 'Rappi'];
  let km = 15000;
  const hoje = new Date();
  for (let i = 1; i <= 9; i++) {
    const d = new Date(hoje); d.setDate(hoje.getDate() - i);
    const dia = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    const rodou = 60 + ((i * 17) % 50);
    const [t] = await pool.query(
      'INSERT INTO turno (usuario_id, data, hora_inicio, hora_fim, km_inicial, km_final) VALUES (?, ?, ?, ?, ?, ?)',
      [uid, dia, `${dia} 09:00:00`, `${dia} 17:00:00`, km, km + rodou]);
    km += rodou;
    await pool.query('INSERT INTO abastecimento (turno_id, litros, valor) VALUES (?, ?, ?)', [t.insertId, 4 + (i % 3), 26 + (i % 4) * 4]);
    for (let g = 0; g < 3; g++) {
      await pool.query('INSERT INTO ganho (turno_id, plataforma, valor) VALUES (?, ?, ?)',
        [t.insertId, plataformas[(i + g) % plataformas.length], 40 + ((i * 13 + g * 29) % 60)]);
    }
  }
}
module.exports = popular;

if (require.main === module) {
  const pool = require('./db');
  popular(pool, process.argv[2])
    .then(() => { console.log('Pronto! Dados de exemplo criados. Atualize o painel.'); process.exit(0); })
    .catch((e) => { console.error('Erro:', e.message); process.exit(1); });
}
